<?php

return [
    'Id'          => 'ID',
    'Category_id' => '分类ID',
    'Title'       => '标题',
    'Content'     => '内容',
    'Image'       => '大图',
    'Username'    => '用户名',
    'Avatar'      => '头像',
    'Views'       => '点击',
    'Comments'    => '评论数',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
