<?php

return [
    'Pid'         => '父分类ID',
    'Name'        => '分类名称',
    'Nickname'    => '分类昵称',
    'Flag'        => '分类标志',
    'Image'       => '图片',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
