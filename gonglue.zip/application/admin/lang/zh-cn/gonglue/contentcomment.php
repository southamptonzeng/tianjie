<?php

return [
    'Id'         => 'ID',
    'Content_id' => '内容ID',
    'Pid'        => '父ID',
    'Username'   => '用户名',
    'Avatar'     => '头像',
    'Content'    => '内容',
    'Comments'   => '评论数',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
